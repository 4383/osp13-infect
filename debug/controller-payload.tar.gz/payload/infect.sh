docker ps
